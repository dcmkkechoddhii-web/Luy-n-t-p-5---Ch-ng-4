#include <iostream>
using namespace std;

void tinhTrungBinh(int &a, int &b, int &c, float &tb) {
    tb = (a + b + c) / 3.0;
}

int main() {
    int a, b, c;
    float tb;

    cout << "Nhap a, b, c: ";
    cin >> a >> b >> c;

    tinhTrungBinh(a, b, c, tb);

    cout << "Trung binh = " << tb;
    return 0;
}
