#include <iostream>
using namespace std;

int timMax(int a, int b, int c) {
    int max = a;
    if(b > max) max = b;
    if(c > max) max = c;
    return max;
}

int main() {
    int a, b, c;
    cout << "Nhap a, b, c: ";
    cin >> a >> b >> c;

    cout << "Max = " << timMax(a, b, c);
    return 0;
}
