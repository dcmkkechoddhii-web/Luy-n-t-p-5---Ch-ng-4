#include <iostream>
using namespace std;

int tinhTong(int n) {
    int sum = 0;
    for(int i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}

int main() {
    int n;
    cout << "Nhap n: ";
    cin >> n;

    cout << "Tong = " << tinhTong(n);
    return 0;
}
